function toggleCategory(category) {
    var element = document.getElementById(category);
    element.style.display = (element.style.display === "none") ? "block" : "none";
}

function toggleEndpoint(endpoint) {
    var element = document.getElementById(endpoint);
    element.style.display = (element.style.display === "none") ? "block" : "none";
}
